#include<stdio.h>
#include<pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include<time.h>
#include<stdlib.h>

FILE *read_file;

char* file_name;
int number_of_threads;
long file_size = 1000000000; //1GB File

void *seq_read(void*);
void *seq_read_write(void*);
void *random_read(void*);

int BLOCK_SIZE = 0;
char* total_buffer[1024 * 1024 * 1024];

//<read/write>:1/<seq>:2/<rand>:3  <BLOCK_SIZE>  <THREAD>  <FILENAME>

int main(int argc, char* argv[]) {

	printf("\n\n*****************Disk Benchmark*****************");
	int i;
	double timer_val_msec, timer_val_sec, time_sec, Data, Throughput, Latency,
			Total_Data;

	if (argc < 5) {
		printf(
				"Run with valid arguements - <operation> <blocksize> <thread> <filename>");
		return 0;
	}

	else {

	
		number_of_threads = atoi(argv[3]); //Thread count

		BLOCK_SIZE = atoi(argv[2]); //Block Size[8B,8KB,8MB,80MB]
		
		file_name = argv[4]; //File name [.txt]

		pthread_t p_thread[number_of_threads];

		//argv[1][1] : sequential write,read
		if (atoi(argv[1]) == 1) {
			//Sequential WRITE + READ
			clock_t start_time = 0;
			clock_t end_time = 0;

			int k = 0, i = 0;

			long param = file_size / number_of_threads;

			start_time = clock();

			while (k < number_of_threads) {
				long param_new = k * param;
				pthread_create(&p_thread[k], NULL, seq_read_write,
						(void *) (long) param_new);
				k++;
			}

			while (i < number_of_threads) {
				pthread_join(p_thread[i], NULL);
				i++;
			}

			end_time = clock();

			clock_t diff = end_time - start_time;

			time_sec = ((double) diff) / CLOCKS_PER_SEC;

			timer_val_msec = time_sec * 1000;
			
			double Total_size = file_size*number_of_threads;
			Total_Data = Total_size/ 1000000; //MB
			Throughput = Total_Data / time_sec; //MB/sec
			Latency = timer_val_msec/ Total_Data;
			
			printf("\nSequential Read + Write\n");

			printf("\nThread:%d", number_of_threads);
			printf("\nBlock Size:%d", BLOCK_SIZE);
			printf("\nThroughPut : %lf MB/sec", Throughput);
			printf("\nLatency : %lf mSec", Latency);
			printf("\n\n");
		}

		//argv[1][2]: Sequential read
		else if (atoi(argv[1]) == 2) {
			clock_t start_time = 0;
			clock_t end_time = 0;

			int k = 0, i = 0;

			long param = file_size / number_of_threads;

			start_time = clock();

			while (k < number_of_threads) {
				long param_new = k * param;
				pthread_create(&p_thread[k], NULL, seq_read,
						(void *) (long) param_new);
				k++;
			}

			while (i < number_of_threads) {
				pthread_join(p_thread[i], NULL);
				i++;
			}

			end_time = clock();


			clock_t diff = end_time - start_time;

			time_sec = ((double) diff) / CLOCKS_PER_SEC;

			timer_val_msec = time_sec * 1000;
			
			double Total_size = file_size*number_of_threads;
			Total_Data = Total_size/ 1000000; //MB		
			Throughput = Total_Data / time_sec; //MB/sec
			Latency = timer_val_msec/ Total_Data;

			printf("\nSequential Read\n");
			
			printf("\nThread:%d", number_of_threads);
			printf("\nBlock Size:%d", BLOCK_SIZE);
			printf("\nThroughPut : %lf MB/sec", Throughput);
			printf("\nLatency : %lf mSec", Latency);
			printf("\n\n");
		}

		//argv[1][3]: random read
		else if (atoi(argv[1]) == 3) {	
			clock_t start_time = 0;
			clock_t end_time = 0;

			int k = 0, i = 0;

			long param = file_size / number_of_threads;

			start_time = clock();

			while (k < number_of_threads) {
				long param_new = k * param;
				pthread_create(&p_thread[k], NULL, random_read,
						(void *) (long) param_new);
				k++;
			}

			while (i < number_of_threads) {
				pthread_join(p_thread[i], NULL);
				i++;
			}

			end_time = clock();

			clock_t diff = end_time - start_time;

			time_sec = ((double) diff) / CLOCKS_PER_SEC;

			timer_val_msec = time_sec * 1000;

			double Total_size = file_size*number_of_threads;
			Total_Data = Total_size/ 1000000; //MB		
			Throughput = Total_Data / time_sec; //MB/sec
			Latency = timer_val_msec/ Total_Data;

			printf("\nRandom Read\n");
			
			printf("\nThread:%d", number_of_threads);
			printf("\nBlock Size:%d", BLOCK_SIZE);
			printf("\nThroughPut : %lf MB/sec", Throughput);
			printf("\nLatency : %lf mSec", Latency);
			printf("\n\n");
		}

		else {
			printf("\n Error:");
		}

	}

	return 0;
}


void *seq_read_write(void* arg) {

	long param = (long) arg;

	FILE *fptr = fopen("new_file.txt", "w");
	FILE *fptr_read = fopen(file_name, "r");
	int index;
	long limit_new;

	long denominator = BLOCK_SIZE * number_of_threads;

	limit_new = file_size / denominator;

	fseek(fptr_read, param, SEEK_SET);
	fseek(fptr, param, SEEK_SET);

	for (index = 0; index < limit_new; index++) {
		fread(total_buffer,1,BLOCK_SIZE, fptr_read);
	}

	for (index = 0; index < limit_new; index++) {
		fwrite(total_buffer, 1,BLOCK_SIZE, fptr);
	}

	fclose(fptr);
	pthread_exit(NULL);

}

void *seq_read(void* arg) {
	long param = (long) arg;

	FILE *fptr_read = fopen(file_name, "r");
	int index;
	long limit_new;

	long denominator = BLOCK_SIZE * number_of_threads;

	limit_new = file_size / denominator;

	fseek(fptr_read, param, SEEK_SET);

	for (index = 0; index < limit_new; index++) {
		fread(total_buffer, 1, BLOCK_SIZE, fptr_read);
	}
	
	fclose(fptr_read);
	pthread_exit(NULL);
}


void *random_read(void* arg) {

	long param = (long) arg;

	FILE *fptr_read = fopen(file_name, "r");
	int index;
	long limit_new;

	long denominator = BLOCK_SIZE * number_of_threads;

	limit_new = file_size / denominator;
	
	int random_count = rand() % 100;
	
	fseek(fptr_read, random_count, SEEK_SET);

	for (index = 0; index < limit_new; index++) {
		fread(total_buffer, 1, BLOCK_SIZE, fptr_read);
	}
	
	fclose(fptr_read);
	pthread_exit(NULL);
}
