#include<stdio.h>
#include<pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include<time.h>
#include<cstdlib>
#include<cstring>
#include <iostream>

using namespace std;

int number_of_threads;
long iterations = 1000000000; 

void *seq_write(void*);
void *seq_read_write(void*);
void *random_write(void*);

int BLOCK_SIZE;

//<read/write>:1/<seq>:2/<rand>:3  <BLOCK_SIZE>  <THREAD> 

int main(int argc, char* argv[]) {
	
	cout<<"\n************ Starting MEMORY Benchmark ************"<<endl;
	
	int i;
	double timer_val_msec, timer_val_sec, time_sec, Data, Throughput, Latency,
			Total_Data;

	if (argc < 3) {
		cout << "Run with valid arguements - <operation> <blocksize> <thread>" << endl;
		return 0;
	}

	else {
		number_of_threads = atoi(argv[3]); //Thread count

		BLOCK_SIZE = atoi(argv[2]); //Block Size[8B,8KB,8MB,80MB]

		pthread_t p_thread[number_of_threads];
		if (atoi(argv[1]) == 1) {
			//Sequential READ+WRITE
			clock_t start_time = 0;
			clock_t end_time = 0;

			int k = 0, i = 0;

			long param = iterations / BLOCK_SIZE;

			start_time = clock();

			while (k < number_of_threads) {
				
				pthread_create(&p_thread[k], NULL, seq_read_write,
						(void *) (long) param);
				k++;
			}

			while (i < number_of_threads) {
				pthread_join(p_thread[i], NULL);
				i++;
			}

			end_time = clock();

			clock_t diff = end_time - start_time;

			time_sec = ((double) diff) / CLOCKS_PER_SEC;

			timer_val_msec = time_sec * 1000;
			
			Total_Data = iterations/ 1000000; //MB
			Throughput = (Total_Data*number_of_threads) / time_sec; //MB/sec
			
			Latency = timer_val_msec/ param;
			
			cout << "\nSequential Read + Write\n";

			cout << "\nThread: " << number_of_threads;
			cout << "\nBlock Size: " << BLOCK_SIZE;
			cout << "\nThroughPut in MB/sec: " << Throughput;
			cout << "\nLatency in mSec: " << Latency;
			cout << "\n\n";
		}
		
		//argv[1][2]: Sequential write
		else if (atoi(argv[1]) == 2) {
			clock_t start_time = 0;
			clock_t end_time = 0;

			int k = 0, i = 0;

			long param = iterations / BLOCK_SIZE;

			start_time = clock();

			while (k < number_of_threads) {
				pthread_create(&p_thread[k], NULL, seq_write,
						(void *) (long) param);
				k++;
			}

			while (i < number_of_threads) {
				pthread_join(p_thread[i], NULL);
				i++;
			}

			end_time = clock();


			clock_t diff = end_time - start_time;

			time_sec = ((double) diff) / CLOCKS_PER_SEC;

			timer_val_msec = time_sec * 1000;
			
			Total_Data = iterations/ 1000000; //MB
			Throughput = (Total_Data*number_of_threads) / time_sec; //MB/sec
			
			Latency = timer_val_msec/ param;
			
			cout << "\nSequential Write\n";

			cout << "\nThread: " << number_of_threads;
			cout << "\nBlock Size: " << BLOCK_SIZE;
			cout << "\nThroughPut in MB/sec: " << Throughput;
			cout << "\nLatency in mSec: " << Latency;
			cout << "\n\n";
			
		}

		//argv[1][3]: random write
		else if (atoi(argv[1]) == 3) {	
			clock_t start_time = 0;
			clock_t end_time = 0;

			int k = 0, i = 0;

			long param = iterations / BLOCK_SIZE;

			start_time = clock();

			while (k < number_of_threads) {
				pthread_create(&p_thread[k], NULL, random_write,
						(void *) (long) param);
				k++;
			}

			while (i < number_of_threads) {
				pthread_join(p_thread[i], NULL);
				i++;
			}

			end_time = clock();

			clock_t diff = end_time - start_time;

			time_sec = ((double) diff) / CLOCKS_PER_SEC;

			timer_val_msec = time_sec * 1000;

			Total_Data = iterations/ 1000000; //MB
			Throughput = (Total_Data*number_of_threads) / time_sec; //MB/sec
			
			Latency = timer_val_msec/ param;
			
			cout << "\nRandom Write\n";

			cout << "\nThread: " << number_of_threads;
			cout << "\nBlock Size: " << BLOCK_SIZE;
			cout << "\nThroughPut in MB/sec: " << Throughput;
			cout << "\nLatency in mSec: " << Latency;
			cout << "\n\n";
		}

		else {
			cout << "\n Error:";
		}

	}

	return 0;
}

//MEMCPY
void *seq_read_write(void* arg) {

		
	long param = (long) arg;
	
	char* mem_source = new char[iterations];
	char* mem_dest = new char[iterations];
	
	long index;
	
	for (index = 0; index < param; index++) {
		
		memcpy(mem_dest + index * BLOCK_SIZE, mem_source + index * BLOCK_SIZE,BLOCK_SIZE);
	}
	pthread_exit(NULL);

}

void *seq_write(void* arg) {
	long param = (long) arg;
	
	char* mem_dest = new char[iterations];
	long index;	
	
	for (index = 0; index < param; index++) {
		
		memset(mem_dest + index * BLOCK_SIZE,'1',BLOCK_SIZE);
	}
	pthread_exit(NULL);
}


void *random_write(void* arg) {
	long param = (long) arg;
	
	char* mem_dest = new char[iterations];
	long index;	
	
	for (index = 0; index < param; index++) {
		
		int random_count = rand() % param;
		
		memset(mem_dest + random_count * BLOCK_SIZE,'1',BLOCK_SIZE);
	}
	pthread_exit(NULL);	
}
