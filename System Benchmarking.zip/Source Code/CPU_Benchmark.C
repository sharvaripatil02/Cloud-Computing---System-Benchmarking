#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>

double iterations;

void *sum_iops_general(void* arg)
{
    int sum=1,i;
    
    for(i=0; i<iterations;i++)
    {
		sum = 43 + 54 +
		62 + 32+
		52 + 55+
		52 + 54+
		52 + 58+
		52 + 52+
		52 + 56+
		52 + 54+
		52 + 59+
		52 + 34+
		23;
		
    }
	pthread_exit(NULL);
	
}
    

void *sum_flops_general(void* arg)
{
    
    float sum;
	int i;
    
    for(i=0; i<iterations;i++)
    {
		
		sum = 0.2 + 0.5 +
		0.2 + 0.2+
		0.2 + 0.5+
		0.2 + 0.4+
		0.2 + 0.8+
		0.2 + 0.2+
		0.2 + 0.6+
		0.2 + 0.4+
		0.2 + 0.9+
		0.2 + 0.12+
		12.0;
        
    }
	
    pthread_exit(NULL);     
}


int main(int argc, char *argv[]){
	
	printf("\n\n*****************Starting CPU Benchmark for GFLOPS and IOPS*****************");
	
	double FLOPS;
	double GFLOPS;
	double IOPS;
	double GIOPS;
	double time_sec;
		
	int number_of_threads[4] = {1,2,4,8};
	int k;
		
	//Total thread count = 4	
	for (k=0;k<4;k++)
	{
		clock_t start_time = 0;
		clock_t end_time = 0;
	
		iterations = 1000000000/number_of_threads[k];
		
		pthread_t* pthread_1 = (pthread_t *) malloc (number_of_threads[k]*sizeof(pthread_t));
		pthread_t* pthread_2 = (pthread_t *) malloc (number_of_threads[k]*sizeof(pthread_t));
		
		int i;

	
		printf("\n\nCPU Benchmark GFLOPS for %d thread(s)", number_of_threads[k]);

		start_time = clock();

		for (i = 0; i < number_of_threads[k]; i++){
			pthread_create (&pthread_1[i], NULL, sum_flops_general,NULL);
		}
		
		for (i=0; i<number_of_threads[k]; i++){
			pthread_join(pthread_1[i], NULL);
		}
		end_time = clock();
		
	
		time_sec = (double)(end_time - start_time)/CLOCKS_PER_SEC;
		
		FLOPS = (number_of_threads[k]*20)*(1000000000/time_sec);
		GFLOPS = FLOPS / 1000000000;
		
		printf("\nTotal Time: %lf", time_sec);
		printf("\nFLOPS: %lf", FLOPS);
		printf("\nGFLOPS: %lf", GFLOPS);
		printf("\n");
		
	
		/* Starting IOPS */
		int j;
		clock_t start_time_iops = 0;
		clock_t end_time_iops = 0;
		
		printf("\n\nCPU Benchmark GIOPS for %d thread(s)", number_of_threads[k]);

		start_time_iops = clock();

		for (j = 0; j < number_of_threads[k]; j++){
			pthread_create (&pthread_2[i], NULL, sum_iops_general,NULL);
		}
		
		for (j=0; j<number_of_threads[k]; j++){
			pthread_join(pthread_2[i], NULL);
		}
		end_time_iops = clock();

	
		time_sec = (double)(end_time_iops - start_time_iops)/CLOCKS_PER_SEC;
		
		IOPS = (number_of_threads[k]*20)*(1000000000/time_sec);
		GIOPS = IOPS / 1000000000;
		
		printf("\nTotal Time: %lf", time_sec);
		printf("\nIOPS: %lf", IOPS);
		printf("\nGIOPS: %lf", GIOPS);
		printf("\n");
		
	}
	
	return 0;
}


