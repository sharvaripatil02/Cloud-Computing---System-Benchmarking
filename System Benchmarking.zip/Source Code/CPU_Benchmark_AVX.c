#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
#include <immintrin.h>
#include <emmintrin.h>

double iterations;


/*20 Floating point operations*/
void *sum_flops_avx(void* arg){
	int i;
	
	__m256 a = _mm256_set_ps(2.0, 4.0, 6.0, 8.0, 10.0, 12.0, 14.0, 16.0);
	__m256 b = _mm256_set_ps(1.0, 3.0, 5.0, 7.0, 9.0, 11.0, 13.0, 15.0);
	
	for(i=0; i<iterations;i++)
    {
		__m256 result = _mm256_add_ps(a, b);
		__m256 result_sub = _mm256_sub_ps(a, b);
		
	}
	pthread_exit(NULL);
}

void *sum_iops_avx(void* arg)
{
    int i;
	
	__m128i a = _mm_set_epi32(12, 14, 16, 28);
	__m128i b = _mm_set_epi32(11, 13, 45,17);
			
	for(i=0; i<iterations;i++)
    {	
		__m128i result = _mm_add_epi32(a, b);
		__m128i result_sub = _mm_sub_epi32(a, b);
		__m128i result_mul = _mm_mul_epi32(a, b);
		__m128i result_1 = _mm_add_epi32(a, b);
	}
    pthread_exit(NULL);
}

int main(int argc, char *argv[]){
	
	printf("\n\n*****************Starting CPU AVX Benchmark for GFLOPS and IOPS*****************");
	
	
	double FLOPS;
	double GFLOPS;
	double IOPS;
	double GIOPS;
	double time_sec;
		
	int number_of_threads[4] = {1,2,4,8};
	int k;
		
	//Total thread count = 4	
	for (k=0;k<4;k++)
	{	
		clock_t start_time = 0;
		clock_t end_time = 0;
	
		iterations = 1000000000/number_of_threads[k];
		
		pthread_t* pthread_1 = (pthread_t *) malloc (number_of_threads[k]*sizeof(pthread_t));
		pthread_t* pthread_2 = (pthread_t *) malloc (number_of_threads[k]*sizeof(pthread_t));
		
		int i;
		
		/* Starting GFLOPS */
		printf("\n\nCPU Benchmark GFLOPS for %d thread(s)", number_of_threads[k]);

		start_time = clock();

		for (i = 0; i < number_of_threads[k]; i++){
			pthread_create (&pthread_1[i], NULL, sum_flops_avx,NULL);
		}
		
		for (i=0; i<number_of_threads[k]; i++){
			pthread_join(pthread_1[i], NULL);
		}
		end_time = clock();

		time_sec = (double)(end_time - start_time)/CLOCKS_PER_SEC;
		
		FLOPS = (number_of_threads[k]*20)*(1000000000/time_sec);
		GFLOPS = FLOPS / 1000000000;
		
		printf("\nTotal Time: %lf", time_sec);
		printf("\nFLOPS: %lf", FLOPS);
		printf("\nGFLOPS: %lf", GFLOPS);
		printf("\n");
		
	
		/* Starting IOPS */
		int j;
		clock_t start_time_iops = 0;
		clock_t end_time_iops = 0;
		
		printf("\n\nCPU Benchmark GIOPS for %d thread(s)", number_of_threads[k]);

		start_time_iops = clock();

		for (j = 0; j < number_of_threads[k]; j++){
			pthread_create (&pthread_2[i], NULL, sum_iops_avx,NULL);
		}
		
		for (j=0; j<number_of_threads[k]; j++){
			pthread_join(pthread_2[i], NULL);
		}
		end_time_iops = clock();
		
	
		time_sec = (double)(end_time_iops - start_time_iops)/CLOCKS_PER_SEC;
		
		IOPS = (number_of_threads[k]*20)*(1000000000/time_sec);
		GIOPS = IOPS / 1000000000;
		
		printf("\nTotal Time: %lf", time_sec);
		printf("\nIOPS: %lf", IOPS);
		printf("\nGIOPS: %lf", GIOPS);
		printf("\n");
		
	}
	
	return 0;
}


