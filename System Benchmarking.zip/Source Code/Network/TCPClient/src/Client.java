import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Arrays;

public class Client {

	public static void main(String args[]) throws Exception {

		String IPAddress;
		int port = 8080;

		if (args.length == 1) {
			IPAddress = args[0];
			int[] threadSequence = { 1, 2, 4, 8 };

			for (int index = 0; index < threadSequence.length; index++) {

				Thread[] threadArray = new Thread[threadSequence[index]];

				int i = 0;
				int k = 0;

				long start = System.nanoTime();

				while (i < threadSequence[index]) {
					threadArray[i] = new Thread(new TCPClientWorker(IPAddress, port, threadSequence[index]));
					threadArray[i].start();
					i++;
				}

				while (k < threadSequence[index]) {
					threadArray[k].join();
					k++;
				}

				long end = System.nanoTime();
				long nano = 1000000L;
				double timetaken = (end - start) / nano;

				System.out.println("For " + threadSequence[index] + " threads");

				calculateThroughput(timetaken);
				calculateLatency(timetaken);

			}

		} else {
			System.out.println("Incorrect Arguments. Try again.");
		}
	}

	public static void calculateThroughput(double time_taken) {
		long total_Data_Tranfered_In_MBits = 65536L;

		double throughput = (total_Data_Tranfered_In_MBits * 250) / time_taken;

		System.out.println("Throughput in MBits/sec: " + throughput);
	}

	public static void calculateLatency(double time_taken) {

		long total_Data_Tranfered_In_Bytes = 8589934592L;
		double latency = (time_taken * 32) / total_Data_Tranfered_In_Bytes;

		System.out.println("Latency in msec: " + latency);
		System.out.println("\n");

	}
}

class TCPClientWorker implements Runnable {

	Socket clientSocket;
	int threadCount;
	String IPAddress;
	int port;

	public TCPClientWorker(String IPAddress, int port, int threadCount) {
		this.IPAddress = IPAddress;
		this.port = port;
		this.threadCount = threadCount;
	}

	@Override
	public void run() {

		ObjectOutputStream toServer = null;
		ObjectInputStream fromServer = null;

		try {
			clientSocket = new Socket(IPAddress, port);
			toServer = new ObjectOutputStream(clientSocket.getOutputStream());
			fromServer = new ObjectInputStream(clientSocket.getInputStream());

			byte[] message = new byte[65536];
			byte[] reply = new byte[65536];
			Arrays.fill(message, (byte) 1);

			long dataSizeInBytes = 8589934592L;
			long limit = dataSizeInBytes / (65536 * threadCount);
			for (long index = 0; index < limit; index++) {
				try {
					toServer.writeObject(message);
					try {
						reply = (byte[]) fromServer.readObject();
					} catch (ClassNotFoundException e) {
						e.printStackTrace();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			toServer.close();
			fromServer.close();
			clientSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
