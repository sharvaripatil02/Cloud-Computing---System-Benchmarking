import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static void main(String args[]) throws Exception {

		int port = 8080;
		ServerSocket myServer = new ServerSocket(port);
		System.out.println("Server started at port: " + port);
		while (true) {
			Socket connSocket = myServer.accept();
			TCPServerWorker worker = new TCPServerWorker(connSocket);
			Thread thread = new Thread(worker);
			thread.start();
		}
	}
}

class TCPServerWorker implements Runnable {

	Socket socket;

	public TCPServerWorker(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {

		try {
			ObjectInputStream fromClient = new ObjectInputStream(socket.getInputStream());
			ObjectOutputStream toClient = new ObjectOutputStream(socket.getOutputStream());
			byte[] inputData = new byte[65536];

			while (true) {
				try {
					inputData = (byte[]) fromClient.readObject();
					toClient.writeObject(inputData);
				} catch (EOFException e) {
					break;
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
				inputData = null;
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
