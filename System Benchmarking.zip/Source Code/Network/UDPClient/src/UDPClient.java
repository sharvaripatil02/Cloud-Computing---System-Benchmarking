import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Arrays;

public class UDPClient {

	public static void main(String args[]) throws Exception {

		String IPAddress;

		if (args.length == 1) {
			IPAddress = args[0];
			int[] threadSequence = { 1, 2, 4, 8 };

			for (int index = 0; index < threadSequence.length; index++) {

				Thread[] threadArray = new Thread[threadSequence[index]];

				int i = 0;
				int k = 0;

				long start = System.nanoTime();

				while (i < threadSequence[index]) {
					threadArray[i] = new Thread(new UDPClientWorker(IPAddress, threadSequence[index]));
					threadArray[i].start();
					i++;
				}

				while (k < threadSequence[index]) {
					threadArray[k].join();
					k++;
				}

				long end = System.nanoTime();
				long nano = 1000000L;
				double timetaken = (end - start) / nano;

				System.out.println("For " + threadSequence[index] + " threads");

				calculateThroughput(timetaken);
				calculateLatency(timetaken);
			}
		} else {
			System.out.println("Incorrect Arguments. Try again.");
		}
	}

	public static void calculateThroughput(double time_taken) {
		long total_Data_Tranfered_In_MBits = 65536L;

		double throughput = (total_Data_Tranfered_In_MBits * 250) / time_taken;

		System.out.println("Throughput in MBits/sec: " + throughput);
	}

	public static void calculateLatency(double time_taken) {

		long total_Data_Tranfered_In_Bytes = 8589934592L;
		double latency = (time_taken * 32) / total_Data_Tranfered_In_Bytes;

		System.out.println("Latency in msec: " + latency);
		System.out.println("\n");

	}
}

class UDPClientWorker implements Runnable {

	DatagramSocket clientSocket;
	int threadCount;
	InetAddress IPAddress;
	byte[] sendMessage;
	byte[] receiveMessage;

	public UDPClientWorker(String ipAddress, int threadCount) throws UnknownHostException {
		this.IPAddress = InetAddress.getByName(ipAddress);
		this.threadCount = threadCount;
	}

	@Override
	public void run() {

		sendMessage = new byte[64512];
		receiveMessage = new byte[64512];
		long dataSizeInBytes = 8589934592L;
		long limit = dataSizeInBytes / (64512 * threadCount);

		Arrays.fill(sendMessage, (byte) 1);

		try {
			clientSocket = new DatagramSocket();
		} catch (SocketException e) {
			e.printStackTrace();
		}

		for (long index = 0; index < limit; index++) {
			DatagramPacket sPacket = new DatagramPacket(sendMessage, sendMessage.length, IPAddress, 6666);
			try {
				clientSocket.send(sPacket);
			} catch (IOException e) {
				e.printStackTrace();
			}
			DatagramPacket rPacket = new DatagramPacket(receiveMessage, receiveMessage.length);
			try {
				clientSocket.receive(rPacket);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		clientSocket.close();
	}
}
