import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class UDPServer {

	public static void main(String args[]) throws Exception {

		UDPServerWorker serverWorker = new UDPServerWorker();
		Thread thread = new Thread(serverWorker);
		thread.start();
	}
}

class UDPServerWorker implements Runnable {
	DatagramSocket serverSocket;
	byte[] receiveMessage;
	byte[] sendMessage;

	public UDPServerWorker() throws SocketException {
		this.serverSocket = new DatagramSocket(6666);
	}

	@Override
	public void run() {

		while (true) {
			receiveMessage = new byte[64512];
			sendMessage = new byte[64512];

			DatagramPacket rPacket = new DatagramPacket(receiveMessage, receiveMessage.length);
			try {
				serverSocket.receive(rPacket);
			} catch (IOException e) {
				e.printStackTrace();
			}
			sendMessage = rPacket.getData();

			InetAddress clientIPAddress = rPacket.getAddress();
			int clientPort = rPacket.getPort();
			DatagramPacket sPacket = new DatagramPacket(sendMessage, sendMessage.length, clientIPAddress, clientPort);
			try {
				serverSocket.send(sPacket);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
